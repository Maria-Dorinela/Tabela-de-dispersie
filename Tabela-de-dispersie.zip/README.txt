      TEMA 3 POO - Tabela de dispersie

SIRBU Maria-Dorinela 332CB

Tema contine 8 clase:

- Clasa BucketImpl care implementeaza interfata Bucket<K,V> si suprascrie metodele acesteia;
- Clasa EntryImpl care implementeaza interfata Entry<K,V> si suprascrie metodele acesteia;
- Clasa HashTester data in scheletul de cod al temei;
- Clasa Student: 
			- contine membrii nume si varsta;
		    - contine metoda hashCode care calculeaza codul de dispersie folosind algoritmul din cerinta temei;
			- contine metoda equals care verifica daca daca obiectul pentru care se apeleaza este echivalent cu obiectul primit ca parametru;
- Clasa LazyStudent: 
			- extinde clasa Student;
		    - contine metoda hashCode care intoarce o valoare constanta(10);
- Clasa MainClass: 
			- metoda "generare_studenti()"  care populeaza un ArrayList cu obiecte de tipul Student;
			- metoda "generare_studenti_lazy()"  care populeaza un ArrayList cu obiecte de tipul LazyStudent;
            - parcurg listele de studenti cu 2 iteratori si introduc studentii intr-un MyHashMapImpl;
	        - fac un numar mare de accesari aleatoare si calculez durata in milisecunde a secventei pentru Student si LazyStudent;
- Clasa MyHashMapImpl: 
			- implementeaza interfata MyHashMap;
            - suprascrie metodele din interfata.

La fiecare metoda am pus comentarii in care am specificat ce am facut mai pe larg.

Am observat ca durata in milisecunde a secventei pentru obiecte de tipul Student este mai mica decat  durata in milisecunde a secventei pentru obiecte de tipul LazyStudent.
