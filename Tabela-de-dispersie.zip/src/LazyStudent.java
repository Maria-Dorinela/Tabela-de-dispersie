/**
 * Clasa LazyStudent care extinde Clasa Student
 * @author Dorinela
 *
 */
public class LazyStudent extends Student{
	
	/**
	 * constructor implicit
	 */
	public LazyStudent(){
		
	}

	/**
	 * constructor cu 2 parametri
	 * @param nume - numele studentului lazy
	 * @param varsta - varsta studentului lazy
	 */
	public LazyStudent(String nume, int varsta){
		super(nume, varsta); 
	}
	
	/**
	 * Suprascrierea medotei hashCode care intoarce o valoare constanta, in cazul meu 10
	 */
	@Override
	public int hashCode(){
		return 10;
	}

}
