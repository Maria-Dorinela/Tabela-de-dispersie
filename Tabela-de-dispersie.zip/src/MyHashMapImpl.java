import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Clasa MyHashMapImpl care implementeaza interfata MyHashMap
 * @author Dorinela
 *
 * @param <K>
 * @param <V>
 */
class MyHashMapImpl<K, V> implements MyHashMap<K, V>{
	
	public int nr_buckets;//variabila in care rerin numarul de bucket-uri
	public ArrayList<BucketImpl<K,V>> buckets;//variabila in care retin bucket-urile
	
	/**
	 * constructor implicit
	 */
	public MyHashMapImpl(){
		
	}
	
	/**
	 * constructor cu un parametru
	 * Initializare "buckets"
	 * @param nr_bucket = numarul de bucket-uri
	 */
	public MyHashMapImpl(int nr_buckets) {
		
		int i;//variabile pentru parcurgere
		
		this.nr_buckets = nr_buckets;
		
		buckets=new ArrayList<BucketImpl<K,V>>();//initializare
		
		if (nr_buckets == 0) { //daca numarul de bucket-uri e 0 atunci "buckets" e null, nu contine nici un element
			buckets = null;
			
		} else //altfel introducem in buckets
			for(i = 0; i < nr_buckets; i++) {
				
				BucketImpl<K,V> new_bucket = new BucketImpl<K,V>();//creare instanta de tipul BucketImpl<K,V>
				buckets.add(new_bucket);//adaugare "new_bucket" in "buckets"
				
			}
			
	}
	
	/**
	 * Matoda care calculeaza codul de dispersie
	 * @param key
	 * @return cod dispersie asociat valorii "key"
	 */
	public int translatare(K key){
		
		int rezultat = 0;//variabila pentru rezulatul final
		
		if(buckets == null){//"buckets" nu contine elemente, rezultatul este 0
			rezultat = 0;
		}
		//daca "buckets" contine elemente
		else{
			//calcul cod dispersie
			rezultat = Math.abs(key.hashCode()) % nr_buckets;
		}
		
			return rezultat;
			
	}

	/**
	 * Metoda care obtine valoarea asociata cheii key.
	 * @param key - cheia a carei aloare o returnez
	 * @return valoarea asociata cheii null daca cheia nu exista
	 */
	@Override
	public V get(K key) {
		// TODO Auto-generated method stub
		
		int translatat;//variabila in care retin codul de dispersie asociat cheii "key"
		Iterator iterator;//variabila folosite pentru parcurgere
		EntryImpl<K, V> e = new EntryImpl<K,V>();
		
		translatat = translatare(key);//apelare metoda "translatare"
		
		
		if (buckets.get(translatat) != null){ //daca pe pozitia generata se afla o valoare
			
			List<EntryImpl<K, V>> l = buckets.get(translatat).list_buckets;
			
			iterator = l.iterator();
			
			//parcurgere
			while (iterator.hasNext()) {
				
				e = (EntryImpl<K, V>) iterator.next();
				
				//daca cheia intrarii "e" este egala cu cheia primita ca parametru
				//atunci returnez valoarea asociata cheii "key" din "e"
				if (e.key == key) {
					return e.value;
				}
				
			}
		}
		
	return null;
	
	}

	/**
	 * Adauga o asociere cheie-valoare in tabela de dispersie.
	 * @param key
	 * @param value
	 * @return valoarea anterioara asociata cheii key sau null daca cheia nu exista
	 */
	@Override
	public V put(K key, V value) {
		// TODO Auto-generated method stub
		
		int translatat;//variabila in care retin codul de dispersie asociat cheii "key"
		V rezultat = null;//valoarea rezultata
		Iterator iterator; //variabila folosita pentru parcurgere
		EntryImpl<K,V> e = new EntryImpl<K,V>();
		boolean ok = false;//variabila booleana ok e falsa daca cheia nu exista in lista
		
		
		translatat  = translatare(key);
		
		if(buckets.get(translatat) != null){//daca pe pozitia generata se afla o valoare
			
			//parcurgere lista de bucket-uri din "buckets"
			iterator = buckets.get(translatat).list_buckets.iterator();
			
			while(iterator.hasNext()){//parcurgere cu iterator
				
				e = (EntryImpl<K, V>) iterator.next();
				
				//daca cheia exista in lista, inlocuiesc valoarea ei cu noua valoare
				if(key.equals(e.getKey())){
					
					rezultat = e.getValue();
					e.value = value;
					ok = true;
					
				}
			}
			
			//daca cheia nu exista, adaugam noua cheie cu valoarea corespunzatoare
			if(ok == false){
				
				//creare intrare noua
				EntryImpl<K, V> nou = new EntryImpl<K, V>(key, value);
				//adaugare intrare noua in "list_buckets" din "buckets" pe pozitia corespunzatoare
				buckets.get(translatat).list_buckets.add(nou);
				
			}
		}
		
		//daca pe pozitia generata nu se afla nicio valoare
		//creez un nou bucket si o noua intrare
		//si adaug intrarea la "list_bucket" al noului bucket
		else if(buckets.get(translatat) == null){
			
			BucketImpl<K,V> nou_bucket = new BucketImpl<K,V>();//creare instanta nou bucket
			EntryImpl<K,V> nou_entry = new EntryImpl<K,V>();//creare instanta intrare noua
			
			nou_bucket.list_buckets.add(nou_entry);//adaugare "nou_entry" la "list_buckets" a lui "nou_bucket"
			
		}
		
		return rezultat;
	}

	/**
	 * Inlatura asocierea.
	 * 
	 * @param key
	 * @return valoarea asociata cu cheia key sau null daca cheia nu exista
	 */
	@Override
	public V remove(K key) {
		// TODO Auto-generated method stub
		
		int translatat;//variabila in care retin codul de dispersie asociat cheii "key"
		V rezultat = null;//valoarea stearsa
		Iterator iterator; //variabila folosita pentru parcurgere
		EntryImpl<K,V> e = new EntryImpl<K,V>();
		
		translatat = translatare(key);
		
		if(buckets.get(translatat) != null){//daca pe pozitia generata se afla o valoare
			
			//parcurgere lista de bucket-uri din "buckets"
			iterator = buckets.get(translatat).list_buckets.iterator();
			
			while(iterator.hasNext()){
				
				e = (EntryImpl<K, V>) iterator.next();
				
				//daca cheia intrarii "e" este egala cu cheia primita ca parametru
				//atunci returnez valoarea asociata cheii "key" din "e" si sterg intrarea
				if(e.key.equals(key)){
					rezultat = e.value;
					iterator.remove();//stergere intrare 
				}
			}
		}
		
		return rezultat;

	}

	/**
	 * suprascrie metoda size() din interfata MyHashMap
	 * @return dimensunea tabelei de dispersie
	 */
	@Override
	public int size() {
		// TODO Auto-generated method stub
		
		int size = 0;//variabila care reprezinta dimensiunea tabelei
	    int i;//variabila pentru parcurgere
	    
	    if(nr_buckets == 0){ //daca numarul de bucket-uri este 0 atunci dimensiunea tabelei este la fel, 0.
	    	
	    	size = 0;
	    	
	    }
	    else if(nr_buckets != 0){//daca numarul de bucket-uri este diferit de 0
	    	
	    	
	    	//parcurg "buckets" si calculez dimensiunea
	    	for(i = 0; i < nr_buckets; i++){
	    		size = size + buckets.get(i).getEntries().size();
	    	}
	    	
	    }
	    
		return size;
		
	}

	/**
	 * suprascrie metoda getBuckets() din interfata MyHashMap
	 * @return lista cu bucket-uri - "buckets"
	 */
	@Override
	public List<? extends MyHashMap.Bucket<K, V>> getBuckets() {
		// TODO Auto-generated method stub
		return this.buckets;
	}

}
