/**
 * clasa Student
 * @author Dorinela
 *
 */
public class Student {
	
	private String nume; //variabila in care retin numele unui student
	private Integer varsta; //variabila in care retin varsta unui student
	
	/**
	 * constructor implicit
	 */
	public Student(){
		
	}
	
	/**
	 * constructor cu 2 parametri
	 * @param nume - numele studentului
	 * @param varsta - varsta studentului
	 */
	public Student(String nume, int varsta){
		this.nume = nume;
		this.varsta = varsta;
	}
	
	/**
	 * 
	 * @return varsta 
	 */
	public int getAge(){
		return varsta;
	}
	
	/**
	 * 
	 * @return nume
	 */
	public String getName(){
		return nume;
	}
	
	/**
	 * Metoda care seteaza numele unui student
	 * @param nume - numele setat
	 */
	public void setName(String nume){
		this.nume = nume;
	}
	
	/**
	 * Metoda care seteaza varsta unui student
	 * @param varsta - varsta setata
	 */
	public void setAge(int varsta){
		this.varsta = varsta;
	}
	
	/**
	 * suprascrierea metodei hashCode
	 *
	 */
	@Override
	public int hashCode(){
		
		int h = 17;
		h = 37 * h + nume.hashCode();
		h = 37 * h + varsta.hashCode();
		return h;
		
	}
	
	
	/**
	 * suprascrierea metodei equals
	 */
	
	@Override
	public boolean equals(Object o){
		
		if(o == null)
			return false;
		if(o == this.nume && o == this.varsta)
			return true;
		return false;
		
	}

}
