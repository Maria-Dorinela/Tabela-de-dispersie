import java.security.KeyStore.Entry;
import java.util.ArrayList;
import java.util.List;

/**
 * Clasa BucketImpl care implementeaza interfata Bucket din MyHashMap
 * Bucket al tabelei de dispersie
 * @author Dorinela
 *
 * @param <K>
 * @param <V>
 */
public class BucketImpl<K, V> implements MyHashMap.Bucket<K, V> {
	
	//variabila in care retin bucket-urile
	public ArrayList<EntryImpl<K,V>> list_buckets;
	
	/**
	 * constructor implicit
	 * in acest constructor initializez "list_buckets"
	 */
	public BucketImpl(){
		list_buckets = new ArrayList<EntryImpl<K,V>>();
	}

	/**
	 * Suprascrierea metodei "getEntries()" din interfata Bucket
	 * @return "list_buckets"
	 */
	@Override
	public List<? extends MyHashMap.Entry<K, V>> getEntries() {
		// TODO Auto-generated method stub
		return list_buckets;
	}

}
