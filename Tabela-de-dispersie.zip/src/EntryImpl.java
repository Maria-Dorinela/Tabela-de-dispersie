/**
 * Clasa EntryImpl care implementeaza interfata Entry din MyHashMap
 * Asociere cheie-valoare in tabela de dispersie
 * @author Dorinela
 *
 * @param <K>
 * @param <V>
 */
public class EntryImpl<K, V> implements MyHashMap.Entry<K, V> {
	
	public K key;//cheie in tabela de dispersie
	public V value;//valoare in tabela de dispersie
	
	/**
	 * construcor implicit
	 */
	public EntryImpl(){
		
	}
	
	/**
	 * constructor cu 2 parametri
	 * @param key - cheie in tabela de dispersie
	 * @param value - valoare in tabela de dispersie
	 */
	public EntryImpl(K key, V value){
		this.key = key;
		this.value = value;
	}

	/**
	 * Suprascrierea metodei "getKey()" din interfata Entry
	 * @return cheie din tabel de dispersie
	 */
	@Override
	public K getKey() {
		// TODO Auto-generated method stub
		return this.key;
	}

	/**
	 * Suprascrierea metodei "getValue()" din interfata Entry
	 * @return valoare din tabel de dispersie
	 */
	@Override
	public V getValue() {
		// TODO Auto-generated method stub
		return this.value;
	}

}
