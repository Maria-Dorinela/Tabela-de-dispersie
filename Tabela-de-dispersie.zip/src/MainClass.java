import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Clasa care contine metoda main si inca 2 metode pentru populare cu elemente de tip Student si LazyStudent
 * @author Dorinela
 *
 */
public class MainClass {
	
	/**
	 * populez un ArrayList<Student> cu elemente de tip Student
	 * @return un ArrayList<Student> in care numele unui Student este ales aleator si contine 8 litere
	 * iar varsta, aleasa aleator nu este mai mare ca 50
	 */
	public static ArrayList<Student> generare_studenti(){
		
		//ArrayList-ul populat cu elemente de tip Student
		ArrayList<Student> rezultat = new ArrayList<Student>();
		int i;
		
		//variabila folosite pentru generare aleatoare
		Random random = new Random();
		
		//poulare "rezultat" cu 2000 elemente
		for(i = 0; i < 2000; i++){
			
			StringBuffer nume = new StringBuffer();//variabila in care rerin numele unui Student
			int varsta;//variabila in care retin varsta unui Student
			
			varsta = random.nextInt(50); //generare aleatoare varsta, varsta nu este mai mare ca 50
			
			for(int y=0; y < 8; y++){ //generare aleatoare nume, numele contine 8 litere
				nume.append((char)(random.nextInt(26) + 97));
			}
			
			rezultat.add(new Student(nume.toString(), varsta)); //introducem Student in "rezultat"
			
		}
		
		return rezultat;
		
	}
	
	/**
	 * populez un ArrayList<LazyStudent> cu elemente de tip Student
	 * @return un ArrayList<LazyStudent> in care numele unui Student este ales aleator si contine 8 litere
	 * iar varsta, aleasa aleator nu este mai mare ca 50
	 */
	public static ArrayList<LazyStudent> generare_studenti_lazy(){
		
				//ArrayList-ul populat cu elemente de tip LazyStudent
				ArrayList<LazyStudent> rezultat = new ArrayList<LazyStudent>();
				int i;
				
				//variabila folosite pentru generare aleatoare
				Random random = new Random();
				
				//poulare "rezultat" cu 2000 elemente
				for(i = 0; i < 2000; i++){
					
					StringBuffer nume = new StringBuffer();//variabila in care rerin numele unui LazyStudent
					int varsta;//variabila in care retin varsta unui LazyStudent
					
					varsta = random.nextInt(50); //generare aleatoare varsta, varsta nu este mai mare ca 50
					
					for(int y=0; y < 8; y++){ //generare aleatoare nume, numele contine 8 litere
						nume.append((char)(random.nextInt(26) + 97));
					}
					
					rezultat.add(new LazyStudent(nume.toString(), varsta)); //introducem LazyStudent in "rezultat"
					
				}
				
				return rezultat;
	}
	
	
	/**
	 * metoda main
	 * @param args
	 */
	public static void main(String[] args) {
	
		//variabila de tipul MyHashMapImpl pentru tipul Student
		MyHashMapImpl<Student, Integer> hash_map_student = new MyHashMapImpl<Student,Integer>(50);
		//variabila de tipul MyHashMapImpl pentru tipul LazyStudent
		MyHashMap<LazyStudent, Integer> hash_map_student_lazy = new MyHashMapImpl<LazyStudent,Integer>(50);
		
		Random r = new Random(); //pentru generare aleatoare
		Iterator<Student> iterator; //iterator pentru parcurgerea tipului Student
		Iterator<LazyStudent> iterator1; //itarator pentru parcurgerea tipului LazyStudent
		ArrayList<Student> studenti = new ArrayList<Student>();//ArrrayList populat cu Student
		ArrayList<LazyStudent> studenti_lazy = new ArrayList<LazyStudent>();//ArrrayList populat cu LazyStudent
		long start_student, stop_student, time_student;//variabile pentru determinarea  timpului pentru Student
		long start_student_lazy, stop_student_lazy, time_student_lazy;//variabile pentru determinarea  timpului pentru LazyStudent
		int k,l;//variabile pentru parcurgere
		
		studenti = generare_studenti();//apelare metoda "generare_studenti()"
		studenti_lazy = generare_studenti_lazy();//apelare metoda "generare_studenti_lazy()"
		
		iterator = studenti.iterator();//folosit pentru parcurgere Student
		iterator1 = studenti_lazy.iterator();//folosit pentru parcurgere LazyStudent
		
		while(iterator.hasNext()){
			
			int nota_student;//variabila pentru retinerea unei note generate aleator
			nota_student = r.nextInt(10);//generare nota aleator, nota sa nu fie mai mare ca 10
			Student stud = iterator.next();
			hash_map_student.put(stud, nota_student); //introducere date in hash_map_student_lazy
			
		}

		while(iterator1.hasNext()){
			
			int nota_student_lazy;//variabila pentru retinerea unei note generate aleator
			nota_student_lazy = r.nextInt(10);//generare nota aleator, nota sa nu fie mai mare ca 10
			LazyStudent stud_lazy = iterator1.next();
			hash_map_student_lazy.put(stud_lazy, nota_student_lazy); //introducere date in hash_map_student_lazy
			
		}
		
		//Fac un numar mare de accesari aleatoare pentru Student si calculez durata in milisecunde a secventei
		start_student = System.currentTimeMillis();//timpul in care secventa incepe
		
		for(l = 0; l < 1100; l++){//numarul de accesari este 1100
			
			int pozitie = 0;//variabila in care retin o pozitie aleatoare
			int valoare = 0;//variabila in care retin valoare de pe pozitia aleasa aleator
			pozitie = Math.abs(r.nextInt(2000));//generare pozitie aleatoare, pozitia sa nu fie mai mare ca 2000, deoarece am 2000 de Student
			valoare = hash_map_student.get(studenti.get(pozitie));//accesare valoare din hash_map_student
			
		}
		
	    stop_student = System.currentTimeMillis();//timpul in care secventa se termina
	    time_student = stop_student - start_student;////calcul durata secventa pentru Student
	    
	    //afisare timp pentru Student
		System.out.println("Durata in milisecunde a secventei pentru STUDENT este: " + time_student);
		
		//Fac un numar mare de accesari aleatoare pentru LazyStudent si calculez durata in milisecunde a secventei
	    start_student_lazy = System.currentTimeMillis();//timpul in care secventa incepe
	    
		for(k = 0; k < 1100; k++){//numarul de accesari este 1100
			
			int pozitie_lazy = 0;//variabila in care retin o pozitie aleatoare
			int valoare_lazy = 0;//variabila in care retin valoare de pe pozitia aleasa aleator
			pozitie_lazy = Math.abs(r.nextInt(2000));//generare pozitie aleatoare, pozitia sa nu fie mai mare ca 2000, deoarece am 2000 de LazyStudent
			valoare_lazy= hash_map_student_lazy.get(studenti_lazy.get(pozitie_lazy));//accesare valoare din hash_map_student_lazy
			
		}   
		
		stop_student_lazy = System.currentTimeMillis();//timpul in care secventa se termina
		time_student_lazy = stop_student_lazy - start_student_lazy;//calcul durata secventa pentru LazyStudent
		
		//afisare timp pentru LazyStudent
		System.out.println("Durata in milisecunde a secventei pentru LAZYSTUDENT este: " + time_student_lazy);
	}

}

